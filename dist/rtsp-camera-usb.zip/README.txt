RTSP Camera Viewer USB package for BMW iDrive 8

Copy the contents of this folder to the root of a USB stick, preserving the
mgu-repo folder.

If MGU Store is already installed:
  1. Plug the USB stick into the car.
  2. Open MGU Store, then Settings.
  3. In MGU Store > Settings > Wi-Fi, scan for and join a network. Connect a
     supported USB/LTE adapter or phone tether if that is your internet source.
  4. In Settings > Preferred connection, select Wi-Fi, USB or Phone, or Auto.
  5. Install or update Tailscale, RTSP Camera Receiver and RTSP Camera. The catalog lists the
     renderer and MGU Uplink dependencies.
     RTSP Camera 0.1.13 shows video on the left with Add Camera, a saved-camera dropdown, edit and trash icons beside the selector, and Stop stream on the right. Deleting a camera asks for confirmation. Existing saved URLs migrate as Cam1. Tap the keyboard text field to position the cursor when editing a camera.
     Private cameras need Tailscale 1.104.9 from the [dapharsyde/car-apps fork](https://github.com/dapharsyde/car-apps),
     which accepts subnet routes in userspace and provides the loopback SOCKS5 proxy.
  6. Restart the head unit when prompted.

If MGU Store is not installed:
  1. Connect a computer to the head unit over its supported SSH route.
  2. Install Node.js 18+ on that computer and use the MGU root SSH key.
  3. From the USB root in PowerShell, run:

     node .\mgu-repo\mgu-store\deploy\mgu-install.js first-install --from .\mgu-repo\mgu-store --identity $HOME\.ssh\mgu_root_key

     Replace the key path with your own. Accept the restart prompt, then use
     MGU Store > Settings > Wi-Fi to join a network, then Settings > Preferred
     connection to select Wi-Fi, USB or Phone (or Auto). Then open MGU Store >
     USB to install RTSP.

Keep the car parked on stable power while installing. Receiver 0.1.21 supports
RTSP over TCP with H.264 video and camera Digest MD5 authentication. Public
camera connections use MGU Uplink. Private IPv4 cameras use Tailscale tool
1.104.9's loopback SOCKS5 proxy on 127.0.0.2:1055; Tailscale traffic also
uses MGU Uplink. Private camera packets do not use the HU's normal IP routes.
The receiver does not use FFmpeg.

Package contents:
  mgu-repo\mgu-store\  Official MGU Store release catalog and bootstrap packages
  mgu-repo\car-apps\   Forked Tailscale 1.104.9 tool, preserving its original Store source identity
  mgu-repo\local\      RTSP Camera app and receiver install catalog

Project: https://github.com/robertnisipeanu/mgu-store





















